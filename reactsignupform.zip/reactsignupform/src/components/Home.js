import React, { useState } from 'react';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import { NavLink } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import SIgn_img from './SIgn_img';

const Home = () => {
  const history = useNavigate();

  const [inpval, setInpval] = useState({
    firstname: '',
    lastname: '',
    email: '',
    mobile: '',
    password: '',
  });

  const getdata = (e) => {
    const { value, name } = e.target;
    setInpval((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const addData = async (e) => {
    e.preventDefault();

    const { firstname, lastname, email, mobile, password } = inpval;

    if (!firstname || !lastname || !email || !mobile || !password) {
      toast.error('All fields are required!', {
        position: 'top-center',
      });
    } else if (!email.includes('@')) {
      toast.error('Please enter a valid email address', {
        position: 'top-center',
      });
    } else if (password.length < 5) {
      toast.error('Password must be at least 5 characters long', {
        position: 'top-center',
      });
    } else {
      try {
        const response = await fetch('http://localhost:5000/api/user/register', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(inpval),
        });

        if (response.ok) {
          toast.success('Registration successful!', {
            position: 'top-center',
          });
          history('/login');
        } else {
          toast.error('Registration failed. Please try again later.', {
            position: 'top-center',
          });
        }
      } catch (error) {
        console.error('Error during registration:', error);
        toast.error('An error occurred. Please try again later.', {
          position: 'top-center',
        });
      }
    }
  };

  return (
    <>
      <div className="container mt-3">
        <section className="d-flex justify-content-between">
          <div className="left_data mt-3 p-3" style={{ width: '100%' }}>
            <h3 className="text-center col-lg-6">Sign Up</h3>
            <Form>
              <Form.Group className="mb-3 col-lg-6" controlId="formBasicFirstname">
                <Form.Control type="text" name="firstname" onChange={getdata} placeholder="Enter Your Firstname" />
              </Form.Group>
              <Form.Group className="mb-3 col-lg-6" controlId="formBasicLastname">
                <Form.Control type="text" name="lastname" onChange={getdata} placeholder="Enter Your Lastname" />
              </Form.Group>
              <Form.Group className="mb-3 col-lg-6" controlId="formBasicEmail">
                <Form.Control type="email" name="email" onChange={getdata} placeholder="Enter email" />
              </Form.Group>
              <Form.Group className="mb-3 col-lg-6" controlId="formBasicMobile">
                <Form.Control type="tel" name="mobile" onChange={getdata} placeholder="Enter mobile number" />
              </Form.Group>
              <Form.Group className="mb-3 col-lg-6" controlId="formBasicPassword">
                <Form.Control type="password" name="password" onChange={getdata} placeholder="Password" />
              </Form.Group>
              <Button variant="primary" className="col-lg-6" onClick={addData} style={{ background: 'rgb(67, 185, 127)' }} type="submit">
                Submit
              </Button>
            </Form>
            <p className="mt-3">
              Already Have an Account ? <span><NavLink to="/login">SignIn</NavLink></span>{' '}
            </p>
          </div>
          <SIgn_img/>
        </section>
        <ToastContainer />
      </div>
    </>
  );
};

export default Home;
