import React, { useState } from 'react';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import SIgn_img from './SIgn_img';
import { useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const BASE_URL = 'http://localhost:5000/api'; // Update with your backend URL

const loginUser = async (credentials) => {
  try {
    const response = await fetch(`${BASE_URL}/user/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(credentials),
    });

    // Check if the response status is OK (status code 2xx)
    if (response.ok) {
      const data = await response.json();
      return data;
    } else {
      // If response status is not OK, throw an error
      throw new Error('Invalid response from the server');
    }
  } catch (error) {
    // Log the error for debugging
    console.error('Error during login:', error);
    // Throw a new error to be caught in the calling function
    throw new Error('An error occurred during login');
  }
};

const Login = () => {
  const history = useNavigate();

  const [inpval, setInpval] = useState({
    email: '',
    password: '',
  });

  const getdata = (e) => {
    const { value, name } = e.target;
    setInpval((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const addData = async (e) => {
    e.preventDefault();

    const { email, password } = inpval;

    if (!email || !password) {
      toast.error('Email and password are required!', {
        position: 'top-center',
      });
    } else {
      try {
        const data = await loginUser({ email, password });

        // Check if the data.message is available and is 'Login successful'
        if (data && data.message === 'Login successful') {
          toast.success(data.message, {
            position: 'top-center',
          });

          // Redirect to the details page or any other page after successful login
          history('/details');
        } else {
          // Display an error message from the server or a default message
          toast.error(data.message || 'Invalid credentials', {
            position: 'top-center',
          });
        }
      } catch (error) {
        // Display a generic error message for unexpected errors
        console.error('Error during login:', error);
        toast.error('An error occurred during login', {
          position: 'top-center',
        });
      }
    }
  };

  return (
    <>
      <div className="container mt-3">
        <section className="d-flex justify-content-between">
          <div className="left_data mt-3 p-3" style={{ width: '100%' }}>
            <h3 className="text-center col-lg-6">Sign In</h3>
            <Form>
              <Form.Group className="mb-3 col-lg-6" controlId="formBasicEmail">
                <Form.Control type="email" name="email" onChange={getdata} placeholder="Enter email" />
              </Form.Group>

              <Form.Group className="mb-3 col-lg-6" controlId="formBasicPassword">
                <Form.Control type="password" name="password" onChange={getdata} placeholder="Password" />
              </Form.Group>
              <Button
                variant="primary"
                className="col-lg-6"
                onClick={addData}
                style={{ background: 'rgb(67, 185, 127)' }}
                type="submit"
              >
                Submit
              </Button>
            </Form>
            <p className="mt-3">
              Don't have an account? <span>SignUp</span>{' '}
            </p>
          </div>
          <SIgn_img />
        </section>
        <ToastContainer />
      </div>
    </>
  );
};

export default Login;
